2024-04-Fullstack-Springboot-React-Mysql-CameraShop

# Tiến Trình

### Part 1 Day 24-04-22
```
4:23 AM cấu hình mysql [4:25 AM hoàn thiện]
4:25 AM thêm 1 ít dữ liệu [4:54 AM hoàn thiện]
4:54 AM hiện thị bên FE [7:45 AM hoàn thiện]
9:12 AM hiển thị bảng con nhập dữ liệu [11:14 AM đi sleep]
```
### Part 2 Day 24-04-23
```
4:46 AM thêm database [5:38 AM hoàn thiện]
5:38 AM Chỉnh sửa hiển thị FE [5:45 AM hoàn thiện]
5:45 AM hiển thị thêm các trường [7:05 AM hoàn thiện]
7:10 AM Danh mục sản phẩm [9:25 AM hoàn thiện]
9:27 AM thêm sản phẩm có chọn danh mục [9:53 AM thất bại đi ngủ]
```
### Part 3 Day 24-04-23
```
8:34 PM thêm sản phẩm có chọn danh mục [10:13 PM thất bại]
10:13 PM đọc hiểu lại code [10:40 PM thất bại]
```

